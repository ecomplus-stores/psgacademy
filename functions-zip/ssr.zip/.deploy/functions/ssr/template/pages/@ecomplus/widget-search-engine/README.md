# Widget Search Engine

Storefront plugin & Vue component for dynamic search page
